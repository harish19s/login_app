export const fakeLogin = async (username, password) => {
   
    if (username === 'dummy.dummy@dummy.com' && password === '12345678') {
      const token = 'your-jwt-token'; 
      localStorage.setItem('token', token);
      return true;
    }
    return false;
  };
  
  export const fakeLogout = () => {
    localStorage.removeItem('token');
  };
  
  export const isAuthenticated = () => {
    const token = localStorage.getItem('token');
    return token !== null;
  };
  