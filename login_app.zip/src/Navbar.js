import React from 'react';
import { fakeLogout } from './authService';

function Navbar() {
  const handleLogout = () => {
    fakeLogout();
    
  };

  return (
    <div className="navbar">
      <button onClick={handleLogout}>Logout</button>
      {}
    </div>
  );
}

export default Navbar;
