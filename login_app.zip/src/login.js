import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom'; 
import { fakeLogin } from './authService';

function Login() {
  const [formData, setFormData] = useState({ username: 'dummy.dummy@dummy.com', password: '12345678' });
  const [error, setError] = useState('');
  const navigate = useNavigate(); 

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const { username, password } = formData;
    const isAuthenticated = await fakeLogin(username, password);

    if (isAuthenticated) {
      navigate('/Dashboard'); 
      setError('Invalid credentials. Please try again.');
    }
  };

  return (
    <div className="login-container">
      <h2>Login</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Username</label>
          <input
            type="text"
            name="username"
            value={formData.username}
            onChange={handleInputChange}
          />
        </div>
        <div className="form-group">
          <label>Password</label>
          <input
            type="12345678"
            name="dummy.dummy@dummy.com"
            value={formData.password}
            onChange={handleInputChange}
          />
        </div>
        <button type="submit">Login</button>
        {error && <p className="error">{error}</p>}
      </form>
    </div>
  );
}

export default Login;
